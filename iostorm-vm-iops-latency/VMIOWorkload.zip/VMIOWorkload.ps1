#
# Copyright="?Microsoft Corporation. All rights reserved."
#

Configuration ConfigureVMIO {
    param (
        [Parameter(Mandatory)]
        [string]$ControllerVMName,
        [Parameter(Mandatory)]
        [string]$ControllerVMPrivateIP,
        [Parameter(Mandatory)]
        [string]$VMName,
        [Parameter(Mandatory)]
        [string]$VMAdminUserName,
        [Parameter(Mandatory)]
        [string]$VMAdminPassword,
        [int32]$VMIoBlockSize = 4096,
        [int32]$VMIoDuration = 60,
        [int32]$VMIoReadPercentage = 70,
        [int32]$VMIoMaxLatency = 100,
        [int32]$FixedIops = 0,
        [bool]$RunFixedIoLatencyTestAfterGoalSeek = $false,
        [int32]$DataDisks = 1
    )

    netsh advfirewall set privateprofile state off
    $PSPath = $PSCommandPath
    
    # DSC Script Resource
    Script VMIOAll {
        TestScript = { $false }

        GetScript = { return @{}}

        SetScript = {
            $controllerVMName = $using:ControllerVMName
            $controllerVMPrivateIP = $using:ControllerVMPrivateIP
            $vmName = $using:VMName
            $vmAdminUserName = $using:VMAdminUserName
            $vmAdminPassword = $using:VMAdminPassword
            $vmIoBlockSize = $using:VMIoBlockSize
            $vmIoDuration = $using:VMIoDuration
            $vmIoReadPercentage = $using:VMIoReadPercentage
            $vmIoMaxLatency = $using:VMIoMaxLatency
            $vmFixedIops = $using:FixedIops
            $fixedIoAftergoalSeek = $using:RunFixedIoLatencyTestAfterGoalSeek
            $disks = $using:DataDisks
            $psPath = $using:PSPath
            
			# Create a scheduled task to execute controller script asynchronously
            $psScriptDir = Split-Path -Parent -Path $psPath
            $psScriptName = "VMIOWorkloadScript.ps1"
            $psScriptPath = "$psScriptDir\$psScriptName"
            $args = ' -NoProfile -WindowStyle Hidden -Command "& ' + "'" + $psScriptPath + "' '" + $controllerVMName + "' '" + $controllerVMPrivateIP + "' '" + $vmName + "' '" + $vmAdminUserName + "' '" + $vmAdminPassword + "' '" + $vmIoBlockSize + "' '" + $vmIoDuration + "' '" + $vmIoReadPercentage + "' '" + $vmIoMaxLatency + "' '" + $vmFixedIops + "' '" + $fixedIoAftergoalSeek + "' '" + $disks + "'" + '"'
            $action = New-ScheduledTaskAction -Execute "Powershell.exe" -Argument $args
            $trigger = @()
            $trigger += New-ScheduledTaskTrigger -Once -At (Get-Date).AddMinutes(2)
            if($vmFixedIops -ne 0) {
                $trigger += New-ScheduledTaskTrigger -AtStartup
            }
            $settings = New-ScheduledTaskSettingsSet -StartWhenAvailable -RunOnlyIfNetworkAvailable -DontStopOnIdleEnd -RestartCount 3 -RestartInterval 240 -Priority 4 -ErrorAction Ignore 
            Unregister-ScheduledTask -TaskName "VMIOWorkload" -Confirm:0 -ErrorAction Ignore
            Register-ScheduledTask -Action $action -Trigger $trigger -TaskName "VMIOWorkload" -Description "VM iostorm" -User $vmAdminUserName -Password $vmAdminPassword -RunLevel Highest -Settings $settings
        }
    }	
}