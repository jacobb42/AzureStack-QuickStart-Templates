#
# Copyright="?Microsoft Corporation. All rights reserved."
#

Configuration ConfigureVMBootAll
{
    param (
        [Parameter(Mandatory)]
        [PSCredential]$AzureAccountCreds,
        [Parameter(Mandatory)]
        [string]$TenantId,
        [Parameter(Mandatory)]
        [string]$Location,
        [Parameter(Mandatory)]
        [string]$VMName,
        [Parameter(Mandatory)]
        [int32]$VMCount,
        [Parameter(Mandatory)]
        [PSCredential]$VMAdminCreds,
        [Parameter(Mandatory)]
        [string]$AzureStorageAccount,
        [Parameter(Mandatory)]
        [string]$AzureStorageAccessKey,
        [Parameter(Mandatory)]
        [string]$AzureStorageEndpoint,
        [Parameter(Mandatory)]
        [string]$AzureSubscription
    )

    # Turn off private firewall
    netsh advfirewall set privateprofile state off
    # Get full path and name of the script being run
    $PSPath = $PSCommandPath

    # Local file storage location
    $localPath = "$env:SystemDrive"

    # Log file
    $logFileName = "VMBootDSC.log"
    $logFilePath = "$localPath\$logFileName"
    
    $AzureAccountUsername = $AzureAccountCreds.UserName
    $AzureAccountPasswordBSTR = [System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($AzureAccountCreds.Password)
    $AzureAccountPassword = [System.Runtime.InteropServices.Marshal]::PtrToStringAuto($AzureAccountPasswordBSTR)
    
    $VMAdminUserName = $VMAdminCreds.UserName
    $VMAdminPasswordBSTR = [System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($VMAdminCreds.Password)
    $VMAdminPassword = [System.Runtime.InteropServices.Marshal]::PtrToStringAuto($VMAdminPasswordBSTR)



    # DSC Script Resource - VM Bootstorm
    Script VMBAll
    {
        TestScript = { (Get-ScheduledTask -TaskName "VMBootAll" -ErrorAction SilentlyContinue) -ne $null }

        GetScript = { return @{"TaskName" = "VMBootAll"} }

        SetScript = {
            # Azure uses AzureAdApplicationId and AzureAdApplicationPassword values as AzureUserName and AzurePassword parameters respectively
            # AzureStack uses tenant UserName and Password values as AzureUserName and AzurePassword parameters respectively
            $azureUsername = $using:AzureAccountUsername
            $azurePassword = $using:AzureAccountPassword
            $tenant = $using:TenantId
            $location = $using:Location
            $vmName = $using:VMName
            $vmCount = $using:VMCount
            # Scheduled task execution credentials without any logged-in user
            $vmAdminUserName = $using:VMAdminUserName
            $vmAdminPassword = $using:VMAdminPassword
            $storageAccount = $using:AzureStorageAccount
            $storageKey = $using:AzureStorageAccessKey
            $storageEndpoint = $using:AzureStorageEndpoint
            $subscription = $using:AzureSubscription
            $adminCreds = $using:VMAdminCreds

            $storageEndpoint = $storageEndpoint.ToLower()
            # Prepare storage context to upload results to Azure storage table
            if($storageEndpoint.Contains("blob")) {
                $storageEndpoint = $storageEndpoint.Substring($storageEndpoint.LastIndexOf("blob") + "blob".Length + 1)
                $storageEndpoint = $storageEndpoint.replace("/", "")
                # Remove port number from storage endpoint e.g. http://saiostorm.blob.azurestack.local:3456/
                if($storageEndpoint.Contains(":")) {
                    $storageEndpoint = $storageEndpoint.Substring(0, $storageEndpoint.LastIndexOf(":"))
                }
            }
            
            "Storage endpoint given: $using:AzureStorageEndpoint Storage endpoint passed to script: $storageEndpoint" | Tee-Object -FilePath $logFilePath -Append
            "user: $vmAdminUserName pwd: $vmAdminPassword" | Tee-Object -FilePath $logFilePath -Append
            $psPath = $using:PSPath
            $psScriptDir = Split-Path -Parent -Path $psPath
            $psScriptName = "VMBootAllScript.ps1"
            $psScriptPath = "$psScriptDir\$psScriptName"
            "current user: $env:USERNAME" | Tee-Object -FilePath $logFilePath -Append
            $createScheduledTaskScript = {
                try {
                    $action = New-ScheduledTaskAction -Execute 'Powershell.exe' -Argument "& $using:psScriptPath -azureUserName $using:azureUsername -azurePassword $using:azurePassword -tenant $using:tenant -location $using:location -vmName $using:vmName -vmCount $using:vmCount -azureStorageAccount $using:storageAccount -azureStorageAccessKey $using:storageKey -azureStorageEndpoint $using:storageEndpoint -AzureSubscription $using:subscription -Verbose" 
                } catch {
                    "Failed to create scheduled task action $_" | Tee-Object -FilePath $using:logFilePath -Append
                }
                try {
                    $trigger = New-ScheduledTaskTrigger -Once -At (Get-Date).AddMinutes(5) -RepetitionInterval (New-TimeSpan -Minutes 10) -RepetitionDuration (New-TimeSpan -Minutes 30) 
                } catch {
                    "Failed to create scheduled task trigger $_" | Tee-Object -FilePath $using:logFilePath -Append
                }
                try {
                    $settings = New-ScheduledTaskSettingsSet -StartWhenAvailable -RunOnlyIfNetworkAvailable -DontStopOnIdleEnd -RestartCount 3 -RestartInterval (New-TimeSpan -Minutes 2) -Priority 4                
                } catch {
                    "Failed to create scheduled settings set $_" | Tee-Object -FilePath $using:logFilePath -Append
                }
                Unregister-ScheduledTask -TaskName "VMBootAll" -Confirm:0 -ErrorAction Ignore
                try {
                    #Register-ScheduledTask -Action $action -Trigger $trigger -Settings $settings -TaskName "VMBootAll" -Description "VMBootstorm" -User $vmAdminUserName -Password $vmAdminPassword -RunLevel Highest | Tee-Object -FilePath $logFilePath -Append -ErrorAction Stop
                    Register-ScheduledTask -Action $action -Trigger $trigger -Settings $settings -TaskName "VMBootAll" -Description "VMBootstorm" -RunLevel Highest | Tee-Object -FilePath $using:logFilePath -Append -ErrorAction Stop
                } catch {
                    "Failed to register scheduled test $_" | Tee-Object -FilePath $using:logFilePath -Append
                }
            }
            $job = Start-Job -ScriptBlock $createScheduledTaskScript -Credential $adminCreds
            $jobResults = Receive-Job -Job $job -Wait
            
            $task = Get-ScheduledTask -TaskName "VmBootAll" -ErrorAction Ignore
            $task | fl * | Tee-Object -FilePath $logFilePath -Append
            "Scheduled task created" | Tee-Object -FilePath $logFilePath -Append
            ######################
            ### AZURE RM SETUP ###
            ######################
            $logFilePath = $using:logFilePath
            $azureStackSdkPath = $using:azureStackSdkPath
            $azureStackInstallerPath = $using:azureStackInstallerPath
            # AzureStack
            if($location.Contains("local")) {
                # Ignore server certificate errors to avoid https://api.azurestack.local/ certificate error
                add-type @"
                using System.Net;
                using System.Security.Cryptography.X509Certificates;
                public class TrustAllCertsPolicy : ICertificatePolicy {
                    public bool CheckValidationResult(
                        ServicePoint srvPoint, X509Certificate certificate,
                        WebRequest request, int certificateProblem) {
                        return true;
                    }
                }
"@
                [System.Net.ServicePointManager]::CertificatePolicy = New-Object TrustAllCertsPolicy
                Write-Warning -Message "CertificatePolicy set to ignore all server certificate errors"

                while (!$installFinished -and $count -lt 5) {
                    try {
                        Install-Module -Name AzureRM -RequiredVersion 1.2.9 -Scope AllUsers -ErrorAction Stop -Confirm:0
                        #Install-Module -Name Azure -Scope AllUsers -ErrorAction Stop -Confirm:0
                        $installFinished = $true
                    }
                    catch {
                        $count++
                        Start-Sleep -Seconds 10
                        Write-Warning "Could not install AzureRM module.  Trying again ($count / 5)"
                    }
                }

                # Import Azure Resource Manager PS module if already present
                try {
                    "Importing Azure module" | Tee-Object -FilePath $logFilePath -Append
                    Import-Module AzureRm -ErrorAction Stop | Out-Null
                } catch [Exception] {
                    "Cannot import Azure module. Cannot proceed further without Azure module. Exception: $_" | Tee-Object -FilePath $logFilePath -Append
                }
            }
            # Azure Cloud
            else {
                # Import Azure Resource Manager PS module if already present
                try {
                    "Importing Azure module" | Tee-Object -FilePath $logFilePath -Append
                    Import-Module AzureRm -ErrorAction Stop | Out-Null
                    #Import-Module Azure -ErrorAction Stop | Out-Null
                    
                }
                # Install Azure Resource Manager PS module
                catch {
                    # Suppress prompts
                    $ConfirmPreference = 'None'
                    "Cannot import Azure module, proceeding with installation" | Tee-Object -FilePath $logFilePath -Append

                    # Install AzureRM
                    try {
                        Get-PackageProvider -Name nuget -ForceBootstrap -Force | Out-Null
                        Install-Module AzureRm �repository PSGallery �Force -Confirm:0 -Scope AllUsers | Out-Null
                        #Install-Module Azure �repository PSGallery �Force -Confirm:0 -Scope AllUsers | Out-Null
                        #Install-Module AzureRM.Compute �repository PSGallery �Force -Confirm:0 | Out-Null
                    }
                    catch {
                        "Installation of Azure module failed." | Tee-Object -FilePath $logFilePath -Append
                    }

                    # Import AzureRM
                    try {
                        Import-Module AzureRm -ErrorAction Stop | Out-Null
                        #Import-Module AzureRM.Compute -ErrorAction Stop | Out-Null
                        #Import-Module AzureRM.Profile -ErrorAction Stop | Out-Null
                    } catch {
                        "Cannot import Azure module. Try importing after restart PowerShell instance. Cannot proceed further without Azure module." | Tee-Object -FilePath $logFilePath -Append
                    }
                }
            }
            Disable-AzureRmDataCollection 

            # Test status file
            $statusFilePath = "$localPath\VMBootStatus.log"
            
            # Wait for VM bootstorm test to finish if vm count is small and DSC can finish within 90 minutes
            $waitCount = 75
            while(((Test-Path $statusFilePath) -eq $false) -and ($waitCount -gt 0)) {
                "Waiting for bootstorm test to finish $waitCount" | Tee-Object -FilePath $logFilePath -Append
                Start-Sleep -Seconds 60
                $waitCount--
            }
            
            if((Test-Path $statusFilePath) -eq $false) {
                "Bootstorm test finished successfully." | Tee-Object -FilePath $logFilePath -Append
            }
            else {
                "Bootstorm test not finished successfully." | Tee-Object -FilePath $logFilePath -Append
            }
        }
    }    
}
